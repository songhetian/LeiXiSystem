import{r as s,t as l,j as e,cP as N,d1 as w,d2 as k,av as y,K as _,a1 as z,E as S,k as E}from"./vendor-DWOfZFgs.js";import{a as L}from"./api-C-56DNPF.js";import{a as h}from"./fileUtils-DzGHaMdL.js";import"./index-DcbpR3nA.js";const R={travel:"差旅费用",office:"办公费用",entertainment:"招待费用",training:"培训费用",other:"其他费用"},$={transportation:"交通费",accommodation:"住宿费",meals:"餐饮费",communication:"通讯费",office_supplies:"办公用品",printing:"打印复印",gift:"礼品费",venue:"场地费",other:"其他"},I={draft:"草稿",pending:"待审批",approving:"审批中",approved:"已通过",rejected:"已驳回",cancelled:"已撤销"},A={draft:"#999",pending:"#fa8c16",approving:"#1890ff",approved:"#52c41a",rejected:"#f5222d",cancelled:"#999"},U=({reimbursementId:n,onBack:f})=>{var c,d;const[i,g]=s.useState(null),[b,r]=s.useState(!0);s.useEffect(()=>{n&&u()},[n]);const u=async()=>{r(!0);try{const t=await L.get(`/reimbursement/${n}`);t.data.success?g(t.data.data):l.error("获取详情失败")}catch(t){console.error("获取报销详情失败:",t),l.error("获取详情失败")}finally{r(!1)}},j=t=>{const a=h(t.file_url);a?window.open(a,"_blank"):l.error("无法生成预览地址")};return b?e.jsxs("div",{className:"reimbursement-detail loading",children:[e.jsx("style",{children:o}),e.jsx("div",{className:"loading-text",children:"加载中..."})]}):i?e.jsxs("div",{className:"reimbursement-detail",children:[e.jsx("style",{children:o}),e.jsxs("div",{className:"detail-header",children:[e.jsxs("button",{className:"back-btn",onClick:f,children:[e.jsx(N,{})," 返回"]}),e.jsxs("div",{className:"header-info",children:[e.jsx("h1",{className:"detail-title",children:i.title}),e.jsx("span",{className:"detail-no",children:i.reimbursement_no})]}),e.jsx("div",{className:"status-badge",style:{background:A[i.status]},children:I[i.status]})]}),e.jsxs("div",{className:"detail-content",children:[e.jsxs("div",{className:"detail-section",children:[e.jsx("h3",{className:"section-title",children:"基本信息"}),e.jsxs("div",{className:"info-grid",children:[e.jsxs("div",{className:"info-item",children:[e.jsx("span",{className:"info-label",children:"申请人"}),e.jsx("span",{className:"info-value",children:i.applicant_name})]}),e.jsxs("div",{className:"info-item",children:[e.jsx("span",{className:"info-label",children:"部门"}),e.jsx("span",{className:"info-value",children:i.department_name||"-"})]}),e.jsxs("div",{className:"info-item",children:[e.jsx("span",{className:"info-label",children:"报销类型"}),e.jsx("span",{className:"info-value",children:R[i.type]||i.type})]}),e.jsxs("div",{className:"info-item",children:[e.jsx("span",{className:"info-label",children:"匹配审批流程"}),e.jsx("span",{className:"info-value text-blue-600 font-semibold",children:i.workflow_name||"自动匹配中"})]}),e.jsxs("div",{className:"info-item",children:[e.jsx("span",{className:"info-label",children:"报销金额"}),e.jsxs("span",{className:"info-value amount",children:["¥",parseFloat(i.total_amount).toFixed(2)]})]}),e.jsxs("div",{className:"info-item",children:[e.jsx("span",{className:"info-label",children:"创建时间"}),e.jsx("span",{className:"info-value",children:new Date(i.created_at).toLocaleString()})]}),i.submitted_at&&e.jsxs("div",{className:"info-item",children:[e.jsx("span",{className:"info-label",children:"提交时间"}),e.jsx("span",{className:"info-value",children:new Date(i.submitted_at).toLocaleString()})]})]}),i.remark&&e.jsxs("div",{className:"remark-box",children:[e.jsx("span",{className:"remark-label",children:"备注说明"}),e.jsx("p",{className:"remark-text",children:i.remark})]})]}),e.jsxs("div",{className:"detail-section",children:[e.jsx("h3",{className:"section-title",children:"费用明细"}),i.items&&i.items.length>0?e.jsxs("table",{className:"items-table",children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"费用类型"}),e.jsx("th",{children:"金额"}),e.jsx("th",{children:"发生日期"}),e.jsx("th",{children:"说明"})]})}),e.jsx("tbody",{children:i.items.map((t,a)=>e.jsxs("tr",{children:[e.jsx("td",{children:$[t.item_type]||t.item_type}),e.jsxs("td",{className:"amount-cell",children:["¥",parseFloat(t.amount).toFixed(2)]}),e.jsx("td",{children:t.expense_date||"-"}),e.jsx("td",{children:t.description||"-"})]},t.id||a))}),e.jsx("tfoot",{children:e.jsxs("tr",{children:[e.jsx("td",{children:"合计"}),e.jsxs("td",{className:"amount-cell total",children:["¥",parseFloat(i.total_amount).toFixed(2)]}),e.jsx("td",{colSpan:"2"})]})})]}):e.jsx("div",{className:"empty-text",children:"暂无费用明细"})]}),e.jsxs("div",{className:"detail-section",children:[e.jsx("h3",{className:"section-title",children:"发票/附件"}),i.attachments&&i.attachments.length>0?e.jsx("div",{className:"attachment-grid",children:i.attachments.map((t,a)=>{var p,x;const m=(p=t.file_type)==null?void 0:p.includes("image"),v=m?h(t.file_url):null;return e.jsxs("div",{className:"attachment-card",onClick:()=>j(t),children:[e.jsx("div",{className:"attachment-preview",children:m?e.jsx("img",{src:v,alt:t.file_name,className:"thumbnail"}):e.jsx("div",{className:"attachment-icon",children:(x=t.file_type)!=null&&x.includes("pdf")?e.jsx(w,{}):e.jsx(k,{})})}),e.jsx("div",{className:"attachment-name",children:t.file_name}),e.jsxs("div",{className:"attachment-action",children:[e.jsx(y,{})," 预览"]})]},t.id||a)})}):e.jsx("div",{className:"empty-text",children:"暂无附件"})]}),e.jsxs("div",{className:"detail-section",children:[e.jsx("h3",{className:"section-title",children:"审批进度"}),(c=i.approval)!=null&&c.records&&i.approval.records.length>0?e.jsx("div",{className:"timeline",children:i.approval.records.map((t,a)=>e.jsxs("div",{className:`timeline-item ${t.action}`,children:[e.jsxs("div",{className:"timeline-icon",children:[t.action==="approve"&&e.jsx(_,{}),t.action==="reject"&&e.jsx(z,{}),t.action==="return"&&e.jsx(S,{}),!["approve","reject","return"].includes(t.action)&&e.jsx(E,{})]}),e.jsxs("div",{className:"timeline-content",children:[e.jsxs("div",{className:"timeline-header",children:[e.jsx("span",{className:"timeline-user",children:t.approver_name}),e.jsxs("span",{className:"timeline-action",children:[t.action==="approve"&&"审批通过",t.action==="reject"&&"驳回",t.action==="return"&&"退回修改",t.action==="delegate"&&"转交"]})]}),t.opinion&&e.jsx("div",{className:"timeline-opinion",children:t.opinion}),e.jsx("div",{className:"timeline-time",children:new Date(t.approved_at).toLocaleString()})]})]},t.id||a))}):e.jsx("div",{className:"empty-text",children:"暂无审批记录"}),i.status==="approving"&&((d=i.approval)==null?void 0:d.currentNodeId)&&e.jsx("div",{className:"current-node",children:"当前正在等待审批..."})]})]})]}):e.jsxs("div",{className:"reimbursement-detail",children:[e.jsx("style",{children:o}),e.jsx("div",{className:"error-text",children:"报销单不存在"})]})},o=`
  .reimbursement-detail {
    padding: 24px;
    max-width: 900px;
    margin: 0 auto;
  }
  .reimbursement-detail.loading {
    text-align: center;
    padding: 100px;
  }
  .loading-text, .error-text {
    color: #999;
    font-size: 16px;
  }
  .detail-header {
    display: flex;
    align-items: center;
    gap: 20px;
    margin-bottom: 24px;
    padding-bottom: 20px;
    border-bottom: 1px solid #eee;
  }
  .back-btn {
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 8px 16px;
    border: 1px solid #ddd;
    border-radius: 8px;
    background: white;
    cursor: pointer;
    font-size: 14px;
    color: #666;
  }
  .back-btn:hover {
    background: #f5f5f5;
  }
  .header-info {
    flex: 1;
  }
  .detail-title {
    font-size: 20px;
    font-weight: 600;
    color: #1a1a2e;
    margin: 0 0 4px 0;
  }
  .detail-no {
    font-family: monospace;
    color: #667eea;
    font-size: 14px;
  }
  .status-badge {
    padding: 6px 16px;
    border-radius: 16px;
    color: white;
    font-size: 14px;
    font-weight: 500;
  }
  .detail-content {
    display: flex;
    flex-direction: column;
    gap: 24px;
  }
  .detail-section {
    background: white;
    border-radius: 12px;
    padding: 24px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
  }
  .section-title {
    font-size: 16px;
    font-weight: 600;
    color: #1a1a2e;
    margin: 0 0 16px 0;
    padding-bottom: 12px;
    border-bottom: 1px solid #eee;
  }
  .info-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 16px;
  }
  .info-item {
    display: flex;
    flex-direction: column;
    gap: 4px;
  }
  .info-label {
    font-size: 12px;
    color: #888;
  }
  .info-value {
    font-size: 14px;
    color: #333;
    font-weight: 500;
  }
  .info-value.amount {
    font-size: 18px;
    color: #667eea;
    font-weight: 700;
  }
  .remark-box {
    margin-top: 16px;
    padding: 12px;
    background: #f8f9fa;
    border-radius: 8px;
  }
  .remark-label {
    font-size: 12px;
    color: #888;
    display: block;
    margin-bottom: 6px;
  }
  .remark-text {
    margin: 0;
    font-size: 14px;
    color: #555;
    line-height: 1.6;
  }
  .items-table {
    width: 100%;
    border-collapse: collapse;
  }
  .items-table th, .items-table td {
    padding: 12px;
    text-align: left;
    border-bottom: 1px solid #eee;
  }
  .items-table th {
    background: #f8f9fa;
    font-weight: 600;
    font-size: 13px;
    color: #555;
  }
  .items-table .amount-cell {
    font-weight: 600;
    color: #1a1a2e;
  }
  .items-table tfoot td {
    font-weight: 600;
    background: #f8f9fa;
  }
  .items-table .total {
    color: #667eea;
    font-size: 16px;
  }
  .empty-text {
    color: #999;
    text-align: center;
    padding: 20px;
  }
  .attachment-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
    gap: 12px;
  }
  .attachment-card {
    border: 1px solid #eee;
    border-radius: 8px;
    padding: 16px;
    text-align: center;
    cursor: pointer;
    transition: all 0.2s;
  }
  .attachment-card:hover {
    border-color: #667eea;
    background: rgba(102,126,234,0.02);
  }
  .attachment-icon {
    font-size: 32px;
    color: #667eea;
    margin-bottom: 8px;
  }
  .attachment-preview {
    width: 100%;
    height: 100px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 8px;
    overflow: hidden;
    background: #fdfdfd;
    border-radius: 4px;
  }
  .thumbnail {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.3s;
  }
  .attachment-card:hover .thumbnail {
    transform: scale(1.1);
  }
  .attachment-name {
    font-size: 13px;
    color: #333;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    margin-bottom: 8px;
  }
  .attachment-action {
    font-size: 12px;
    color: #1890ff;
  }
  .timeline {
    position: relative;
    padding-left: 30px;
  }
  .timeline::before {
    content: '';
    position: absolute;
    left: 10px;
    top: 0;
    bottom: 0;
    width: 2px;
    background: #eee;
  }
  .timeline-item {
    position: relative;
    padding-bottom: 24px;
  }
  .timeline-item:last-child {
    padding-bottom: 0;
  }
  .timeline-icon {
    position: absolute;
    left: -30px;
    width: 22px;
    height: 22px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 12px;
    background: white;
    border: 2px solid #ddd;
    color: #999;
  }
  .timeline-item.approve .timeline-icon {
    border-color: #52c41a;
    color: #52c41a;
  }
  .timeline-item.reject .timeline-icon {
    border-color: #f5222d;
    color: #f5222d;
  }
  .timeline-item.return .timeline-icon {
    border-color: #fa8c16;
    color: #fa8c16;
  }
  .timeline-content {
    background: #f8f9fa;
    border-radius: 8px;
    padding: 12px 16px;
  }
  .timeline-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 6px;
  }
  .timeline-user {
    font-weight: 600;
    color: #333;
  }
  .timeline-action {
    font-size: 13px;
    padding: 2px 8px;
    border-radius: 4px;
  }
  .timeline-item.approve .timeline-action {
    background: #f6ffed;
    color: #52c41a;
  }
  .timeline-item.reject .timeline-action {
    background: #fff1f0;
    color: #f5222d;
  }
  .timeline-item.return .timeline-action {
    background: #fff7e6;
    color: #fa8c16;
  }
  .timeline-opinion {
    font-size: 14px;
    color: #555;
    margin-bottom: 8px;
    line-height: 1.5;
  }
  .timeline-time {
    font-size: 12px;
    color: #999;
  }
  .current-node {
    text-align: center;
    padding: 16px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border-radius: 8px;
    margin-top: 16px;
  }
`;export{U as default};
