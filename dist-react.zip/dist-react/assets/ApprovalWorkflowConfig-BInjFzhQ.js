import{r as l,t as n,j as e,N as w,aV as j,ad as ve,bz as I,bi as ye,bj as we,B as x,aS as J,U as _e,O as u,ao as L,aD as H,ce as R,W as Ne,d8 as ke,M as T,aX as p,$ as P,d9 as Ce,ch as Se,X as Q,k as $e,K as ze}from"./vendor-DWOfZFgs.js";import{a as d}from"./api-C-56DNPF.js";import{m as Ie,f as A}from"./searchUtils-DnnFZhtm.js";import"./index-DcbpR3nA.js";const{Option:i}=p,{TextArea:Re}=j,Z=[{value:"role",label:"指定角色",icon:e.jsx(Q,{})},{value:"user",label:"指定用户",icon:e.jsx($e,{})},{value:"custom_group",label:"特殊审批组",icon:e.jsx(Q,{})},{value:"initiator",label:"发起人确认",icon:e.jsx(ze,{})}],Te={role:"指定角色",user:"指定用户",custom_group:"特殊审批组",initiator:"发起人确认",department_manager:"部门主管",boss:"老板",finance:"财务"},Ee=()=>{var D,K,X,G;const[ee,h]=l.useState([]),[ae,O]=l.useState(!1),[M,se]=l.useState("card"),[_,re]=l.useState(1),[N,te]=l.useState(12),[oe,ne]=l.useState(""),[o,m]=l.useState(null),[le,k]=l.useState(!1),[ie,C]=l.useState(!1),[v,ce]=l.useState(null),[c,g]=l.useState([]),[W,E]=l.useState([]),[de,B]=l.useState([]),[pe,xe]=l.useState([]);l.useEffect(()=>{console.log("组件挂载，开始加载数据..."),y(),me(),ue(),F()},[]);const y=async()=>{var a,s,r;O(!0);try{const t=await d.get("/approval-workflow");if(console.log("审批流程API完整响应:",t),console.log("审批流程API响应数据:",t.data),t.data&&t.data.success){const f=t.data.data||[];console.log("设置流程数据:",f),h(f)}else if(Array.isArray(t.data))console.log("设置流程数据（数组格式）:",t.data),h(t.data);else if(t.data){const f=t.data.data||t.data;Array.isArray(f)?(console.log("设置流程数据（提取）:",f),h(f)):(console.warn("审批流程API返回格式异常:",t.data),n.error("获取流程列表失败: 数据格式错误"),h([]))}else console.warn("审批流程API返回空响应"),n.error("获取流程列表失败: 无数据返回"),h([])}catch(t){console.error("获取流程列表失败:",t),console.error("错误详情:",(a=t.response)==null?void 0:a.data),n.error("获取流程列表失败: "+(((r=(s=t.response)==null?void 0:s.data)==null?void 0:r.message)||t.message)),h([])}finally{O(!1)}},me=async()=>{try{const a=await d.get("/approvers/available-roles");a.data.success?E(a.data.data||[]):Array.isArray(a.data)&&E(a.data)}catch(a){console.error("获取角色列表失败:",a)}},ue=async(a="")=>{try{const s=await d.get("/approvers/available-users",{params:{keyword:a}});s.data.success?B(s.data.data||[]):Array.isArray(s.data)&&B(s.data)}catch(s){console.error("获取用户列表失败:",s)}},F=async()=>{try{const a=await d.get("/approvers"),s=a.data.success?a.data.data:Array.isArray(a.data)?a.data:[];if(s){const r=[...new Set(s.map(t=>t.approver_type))];xe(r.map(t=>({value:t,label:t})))}}catch(a){console.error("获取自定义审批组失败:",a)}},S=(a=null)=>{m(a?{...a,is_default:!!a.is_default,conditions:typeof a.conditions=="string"?JSON.parse(a.conditions||"{}"):a.conditions||{}}:{name:"",description:"",is_default:!1,status:"active",conditions:{role_ids:[]}}),k(!0)},he=async()=>{if(!o.name.trim()){n.error("请输入流程名称");return}try{const a={...o,type:"reimbursement"};let s;o.id?s=await d.put(`/approval-workflow/${o.id}`,a):s=await d.post("/approval-workflow",a),s.data.success?(n.success(o.id?"更新成功":"创建成功"),k(!1),y()):n.error(s.data.message||"操作失败")}catch(a){console.error("保存流程失败:",a),n.error("保存失败")}},V=async a=>{T.confirm({title:"确认删除",content:"确定要删除此审批流程吗？此操作不可恢复。",okText:"确认删除",okType:"danger",cancelText:"取消",onOk:async()=>{try{const s=await d.delete(`/approval-workflow/${a}`);s.data.success?(n.success("删除成功"),y()):n.error(s.data.message||"删除失败")}catch(s){console.error("删除流程失败:",s),n.error("删除失败")}}})},U=async a=>{ce(a),F();try{const s=await d.get(`/approval-workflow/${a.id}/nodes`);s.data.success&&g(s.data.data)}catch(s){console.error("获取节点失败:",s)}C(!0)},fe=()=>{g([...c,{node_name:"",approver_type:"role",role_id:null,approver_id:null,custom_type_name:null,approval_mode:"serial",can_skip:!1}])},b=(a,s,r)=>{const t=[...c];t[a][s]=r,s==="approver_type"&&(t[a].role_id=null,t[a].approver_id=null,t[a].custom_type_name=null),g(t)},ge=a=>{g(c.filter((s,r)=>r!==a))},Y=(a,s)=>{const r=[...c],t=a+s;t<0||t>=c.length||([r[a],r[t]]=[r[t],r[a]],g(r))},be=async()=>{var a;for(let s=0;s<c.length;s++){const r=c[s];if(!((a=r.node_name)!=null&&a.trim())){n.error(`第 ${s+1} 个节点：请输入节点名称`);return}if(r.approver_type==="role"&&!r.role_id){n.error(`第 ${s+1} 个节点：请选择角色`);return}if(r.approver_type==="user"&&!r.approver_id){n.error(`第 ${s+1} 个节点：请选择用户`);return}if(r.approver_type==="custom_group"&&!r.custom_type_name){n.error(`第 ${s+1} 个节点：请选择特殊审批组类型`);return}}try{const s=await d.post(`/approval-workflow/${v.id}/nodes`,{nodes:c});s.data.success?(n.success("节点配置保存成功"),C(!1),y()):n.error(s.data.message||"保存失败")}catch(s){console.error("保存节点失败:",s),n.error("保存失败")}},$=(a,s)=>{m(r=>({...r,conditions:{...r.conditions,[a]:s}}))},z=ee.filter(a=>Ie(a.name,oe)),q=z.slice((_-1)*N,_*N),je=[{title:"流程名称",dataIndex:"name",key:"name",align:"center",render:(a,s)=>e.jsxs(w,{children:[e.jsx("span",{style:{fontWeight:600},children:a}),s.is_default&&e.jsx(u,{color:"#667eea",children:"默认"})]})},{title:"描述",dataIndex:"description",key:"description",align:"center",ellipsis:!0,render:a=>a||e.jsx("span",{style:{color:"#999"},children:"-"})},{title:"节点数",dataIndex:"node_count",key:"node_count",width:100,align:"center",render:a=>e.jsxs(u,{children:[a||0," 个节点"]})},{title:"状态",dataIndex:"status",key:"status",width:100,align:"center",render:a=>e.jsx(u,{color:a==="active"?"success":"default",children:a==="active"?"启用":"停用"})},{title:"操作",key:"action",width:250,align:"center",render:(a,s)=>e.jsxs(w,{children:[e.jsx(x,{size:"small",icon:e.jsx(L,{}),onClick:()=>U(s),children:"节点"}),e.jsx(x,{size:"small",icon:e.jsx(H,{}),onClick:()=>S(s),children:"编辑"}),!s.is_default&&e.jsx(x,{size:"small",danger:!0,icon:e.jsx(R,{}),onClick:()=>V(s.id),children:"删除"})]})}];return e.jsxs("div",{className:"workflow-config",children:[e.jsx("style",{children:Pe}),e.jsxs("div",{className:"page-header",children:[e.jsxs("div",{children:[e.jsx("h1",{className:"page-title",children:"审批流程配置"}),e.jsx("p",{className:"page-subtitle",children:"配置报销审批流程和节点"})]}),e.jsxs(w,{children:[e.jsx(j,{placeholder:"搜索流程...",prefix:e.jsx(ve,{style:{color:"#bfbfbf"}}),style:{width:200},onChange:a=>ne(a.target.value),allowClear:!0}),e.jsxs(I.Group,{value:M,onChange:a=>se(a.target.value),buttonStyle:"solid",children:[e.jsx(I.Button,{value:"card",children:e.jsx(ye,{})}),e.jsx(I.Button,{value:"list",children:e.jsx(we,{})})]}),e.jsx(x,{type:"primary",icon:e.jsx(J,{}),onClick:()=>S(),className:"btn-primary-custom",children:"新建流程"})]})]}),e.jsx("div",{className:"content-area",children:ae?e.jsx("div",{className:"loading",children:"加载中..."}):z.length===0?e.jsx(_e,{description:"暂无审批流程",style:{padding:"40px 0"}}):e.jsxs(e.Fragment,{children:[M==="card"?e.jsx("div",{className:"workflow-grid",children:q.map(a=>e.jsxs("div",{className:`workflow-card ${a.is_default?"default":""}`,children:[e.jsxs("div",{className:"card-header",children:[e.jsxs("div",{className:"card-title",children:[a.name,a.is_default&&e.jsx("span",{className:"default-badge",children:"默认"})]}),e.jsx("div",{className:"card-status",children:a.status==="active"?e.jsx(u,{color:"#ecfdf5",style:{color:"#059669",border:0,margin:0},children:"启用"}):e.jsx(u,{color:"#f3f4f6",style:{color:"#6b7280",border:0,margin:0},children:"停用"})})]}),e.jsx("div",{className:"card-desc",title:a.description,children:a.description||"暂无描述"}),e.jsxs("div",{className:"card-meta",children:[e.jsxs(u,{children:[a.node_count||0," 个节点"]}),a.conditions&&Object.keys(a.conditions).length>0&&e.jsx(u,{color:"warning",children:"有触发条件"})]}),e.jsxs("div",{className:"card-actions",children:[e.jsxs("button",{className:"action-btn",onClick:()=>U(a),children:[e.jsx(L,{})," 配置节点"]}),e.jsxs("button",{className:"action-btn",onClick:()=>S(a),children:[e.jsx(H,{})," 编辑"]}),!a.is_default&&e.jsxs("button",{className:"action-btn delete",onClick:()=>V(a.id),children:[e.jsx(R,{})," 删除"]})]})]},a.id))}):e.jsx("div",{className:"workflow-table-wrapper",children:e.jsx(Ne,{columns:je,dataSource:q,rowKey:"id",pagination:!1,size:"middle"})}),e.jsx("div",{className:"pagination-wrapper",children:e.jsx(ke,{current:_,pageSize:N,total:z.length,onChange:(a,s)=>{re(a),te(s)},showSizeChanger:!0,showTotal:a=>`共 ${a} 条流程`})})]})}),e.jsx(T,{title:o!=null&&o.id?"编辑流程":"新建流程",open:le,onCancel:()=>k(!1),onOk:he,width:650,centered:!0,okText:"保存",cancelText:"取消",okButtonProps:{className:"btn-primary-custom"},children:o&&e.jsxs("div",{className:"modal-form",children:[e.jsxs("div",{className:"form-group",children:[e.jsx("label",{className:"form-label required",children:"流程名称"}),e.jsx(j,{value:o.name,onChange:a=>m({...o,name:a.target.value}),placeholder:"如：普通员工报销流程"})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{className:"form-label",children:"流程描述"}),e.jsx(Re,{rows:3,value:o.description||"",onChange:a=>m({...o,description:a.target.value}),placeholder:"描述此流程的适用场景..."})]}),e.jsxs("div",{className:"form-row",children:[e.jsxs("div",{className:"form-group",children:[e.jsx("label",{className:"form-label",children:"状态"}),e.jsxs(p,{value:o.status,onChange:a=>m({...o,status:a}),style:{width:"100%"},children:[e.jsx(i,{value:"active",children:"启用"}),e.jsx(i,{value:"inactive",children:"停用"})]})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{className:"form-label",children:"是否设为默认"}),e.jsxs(p,{value:o.is_default,onChange:a=>m({...o,is_default:a}),style:{width:"100%"},children:[e.jsx(i,{value:!1,children:"否 - 需满足条件触发"}),e.jsx(i,{value:!0,children:"是 - 作为兜底流程"})]})]})]}),e.jsxs("div",{className:"condition-section",children:[e.jsx("h4",{className:"section-title",children:"触发条件配置"}),e.jsx("p",{className:"section-hint",children:"当报销申请满足以下条件时，将自动匹配使用此流程"}),e.jsxs("div",{className:"condition-grid",children:[e.jsxs("div",{className:"condition-item",children:[e.jsx("label",{children:"金额大于 (元)"}),e.jsx(j,{type:"number",value:((D=o.conditions)==null?void 0:D.amount_greater_than)||"",onChange:a=>$("amount_greater_than",a.target.value?parseFloat(a.target.value):null),placeholder:"如: 5000",suffix:"RMB"})]}),e.jsxs("div",{className:"condition-item",children:[e.jsx("label",{children:"部门主管专用"}),e.jsxs(p,{value:((K=o.conditions)==null?void 0:K.is_department_manager)===!0?"true":((X=o.conditions)==null?void 0:X.is_department_manager)===!1?"false":"",onChange:a=>$("is_department_manager",a===""?void 0:a==="true"),style:{width:"100%"},children:[e.jsx(i,{value:"",children:"不限"}),e.jsx(i,{value:"true",children:"仅部门主管"}),e.jsx(i,{value:"false",children:"仅非主管"})]})]}),e.jsxs("div",{className:"condition-item full",children:[e.jsx("label",{children:"适用角色 (多选)"}),e.jsx(p,{mode:"multiple",allowClear:!0,style:{width:"100%"},placeholder:"请选择适用的角色",value:((G=o.conditions)==null?void 0:G.role_ids)||[],onChange:a=>$("role_ids",a.length>0?a:void 0),optionFilterProp:"children",maxTagCount:"responsive",children:W.map(a=>e.jsx(i,{value:a.id,children:a.name},a.id))})]})]})]})]})}),e.jsx(T,{title:`配置节点 - ${(v==null?void 0:v.name)||""}`,open:ie,onCancel:()=>C(!1),onOk:be,width:800,centered:!0,okText:"保存配置",cancelText:"取消",okButtonProps:{className:"btn-primary-custom"},children:e.jsx("div",{className:"node-list-container",children:e.jsxs("div",{className:"node-list",children:[c.map((a,s)=>e.jsxs("div",{className:"node-item",children:[e.jsx("div",{className:"node-order",children:s+1}),e.jsxs("div",{className:"node-form",children:[e.jsx(j,{placeholder:"节点名称",value:a.node_name,onChange:r=>b(s,"node_name",r.target.value),style:{width:"25%"}}),e.jsxs(p,{value:a.approver_type,onChange:r=>b(s,"approver_type",r),style:{width:"30%"},placeholder:"请选择类型",children:[Z.map(r=>e.jsx(i,{value:r.value,children:e.jsxs(w,{children:[r.icon," ",r.label]})},r.value)),a.approver_type&&!Z.find(r=>r.value===a.approver_type)&&e.jsx(i,{value:a.approver_type,disabled:!0,children:Te[a.approver_type]||a.approver_type},a.approver_type)]}),e.jsxs("div",{style:{flex:1},children:[a.approver_type==="role"&&e.jsx(p,{placeholder:"请选择角色",showSearch:!0,filterOption:A,value:a.role_id,onChange:r=>b(s,"role_id",r),style:{width:"100%"},children:W.map(r=>e.jsx(i,{value:r.id,children:r.name},r.id))}),a.approver_type==="user"&&e.jsx(p,{showSearch:!0,placeholder:"搜索并选择用户",filterOption:A,value:a.approver_id,onChange:r=>b(s,"approver_id",r),style:{width:"100%"},options:de.map(r=>({value:r.id,label:`${r.real_name} (${r.username})`}))}),a.approver_type==="custom_group"&&e.jsx(p,{placeholder:"请选择审批组类型",showSearch:!0,filterOption:A,value:a.custom_type_name,onChange:r=>b(s,"custom_type_name",r),style:{width:"100%"},options:pe})]})]}),e.jsxs("div",{className:"node-actions",children:[e.jsx(P,{title:"上移",children:e.jsx(x,{size:"small",icon:e.jsx(Ce,{}),onClick:()=>Y(s,-1),disabled:s===0})}),e.jsx(P,{title:"下移",children:e.jsx(x,{size:"small",icon:e.jsx(Se,{}),onClick:()=>Y(s,1),disabled:s===c.length-1})}),e.jsx(P,{title:"删除",children:e.jsx(x,{size:"small",danger:!0,icon:e.jsx(R,{}),onClick:()=>ge(s)})})]})]},s)),e.jsx(x,{type:"dashed",block:!0,icon:e.jsx(J,{}),onClick:fe,style:{marginTop:12,height:48},children:"添加审批节点"})]})})})]})},Pe=`
  .workflow-config {
    padding: 24px;
    max-width: 1200px;
    margin: 0 auto;
  }
  .page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 24px;
  }
  .page-title {
    font-size: 22px;
    font-weight: 600;
    color: #1a1a2e;
    margin: 0;
  }
  .page-subtitle {
    font-size: 14px;
    color: #888;
    margin: 4px 0 0 0;
  }

  /* 列表视图样式 */
  .workflow-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(380px, 1fr));
    gap: 24px;
  }
  .workflow-card {
    background: white;
    border-radius: 16px;
    padding: 24px;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
    border: 1px solid #f3f4f6;
    transition: all 0.2s;
    display: flex;
    flex-direction: column;
  }
  .workflow-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.05), 0 4px 6px -2px rgba(0, 0, 0, 0.025);
    border-color: #e5e7eb;
  }
  .workflow-card.default {
    border: 2px solid #667eea;
  }
  .card-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 16px;
  }
  .card-title {
    font-size: 18px;
    font-weight: 600;
    color: #111827;
    display: flex;
    align-items: center;
    gap: 8px;
  }
  .default-badge {
    font-size: 11px;
    padding: 2px 8px;
    background: #667eea;
    color: white;
    border-radius: 999px;
    font-weight: 500;
  }
  .card-desc {
    font-size: 14px;
    color: #6b7280;
    margin-bottom: 20px;
    line-height: 1.5;
    flex: 1;
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
  }
  .card-meta {
    display: flex;
    gap: 12px;
    font-size: 13px;
    color: #6b7280;
    margin-bottom: 20px;
    padding-top: 16px;
    border-top: 1px solid #f3f4f6;
  }
  .card-actions {
    display: grid;
    grid-template-columns: 1fr 1fr 1fr;
    gap: 12px;
  }
  .action-btn {
    padding: 8px 12px;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    background: white;
    font-size: 13px;
    font-weight: 500;
    color: #4b5563;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    transition: all 0.2s;
  }
  .action-btn:hover {
    background: #f9fafb;
    border-color: #d1d5db;
    color: #111827;
  }
  .action-btn.delete:hover {
    background: #fef2f2;
    color: #dc2626;
    border-color: #fecaca;
  }

  /* 表格视图样式修正 */
  .workflow-table-wrapper {
    background: white;
    padding: 16px;
    border-radius: 12px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
  }

  /* 通用样式 */
  .btn-primary-custom {
    background-color: #667eea !important;
    border-color: #667eea !important;
  }
  .btn-primary-custom:hover {
    background-color: #5a6fd1 !important;
    border-color: #5a6fd1 !important;
  }

  .pagination-wrapper {
    margin-top: 24px;
    display: flex;
    justify-content: flex-end;
  }

  /* 弹窗样式优化 */
  .modal-form {
    padding: 10px 0;
  }
  .form-group {
    margin-bottom: 20px;
  }
  .form-row {
    display: flex;
    gap: 20px;
  }
  .form-row .form-group {
    flex: 1;
  }
  .form-label {
    display: block;
    font-weight: 500;
    color: #374151;
    margin-bottom: 8px;
  }
  .form-label.required::after {
    content: '*';
    color: #ef4444;
    margin-left: 4px;
  }

  .condition-section {
    background: #f8fafc;
    padding: 20px;
    border-radius: 12px;
    border: 1px solid #e2e8f0;
    margin-top: 10px;
  }
  .section-title {
    font-size: 15px;
    font-weight: 600;
    margin: 0 0 4px 0;
  }
  .section-hint {
    font-size: 13px;
    color: #64748b;
    margin: 0 0 16px 0;
  }
  .condition-grid {
    display: flex;
    flex-direction: column;
    gap: 16px;
  }
  .condition-item {
    display: flex;
    flex-direction: column;
    gap: 6px;
  }

  /* 节点列表 */
  .node-list-container {
    max-height: 60vh;
    overflow-y: auto;
    padding-right: 8px;
  }
  .node-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 16px;
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    margin-bottom: 12px;
    transition: all 0.2s;
  }
  .node-item:hover {
    border-color: #cbd5e1;
    background: white;
    box-shadow: 0 2px 8px rgba(0,0,0,0.04);
  }
  .node-order {
    width: 28px;
    height: 28px;
    background: #667eea;
    color: white;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 600;
    font-size: 13px;
    flex-shrink: 0;
  }
  .node-form {
    flex: 1;
    display: flex;
    gap: 12px;
    align-items: center;
  }
  .node-form .ant-select {
    font-size: 13px;
  }
  .node-form .ant-select-selector {
    border-radius: 8px !important;
    border: 1px solid #e2e8f0 !important;
    background: white !important;
  }
  .node-form .ant-select-selector:hover {
    border-color: #cbd5e1 !important;
  }
  .node-form .ant-select-focused .ant-select-selector {
    border-color: #667eea !important;
    box-shadow: 0 0 0 2px rgba(102, 126, 234, 0.1) !important;
  }
  .node-form .ant-input {
    border-radius: 8px !important;
    border: 1px solid #e2e8f0 !important;
    font-size: 13px;
  }
  .node-form .ant-input:hover {
    border-color: #cbd5e1 !important;
  }
  .node-form .ant-input:focus {
    border-color: #667eea !important;
    box-shadow: 0 0 0 2px rgba(102, 126, 234, 0.1) !important;
  }
  .node-actions {
    display: flex;
    gap: 4px;
  }
`;export{Ee as default};
