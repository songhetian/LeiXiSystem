import{r as o,j as e,aU as N,ae as S,av as w,ak as T,ce as z,a1 as C,t as s,M as h}from"./vendor-DWOfZFgs.js";import{a as c}from"./api-C-56DNPF.js";import"./index-DcbpR3nA.js";const R=[{value:"all",label:"全部状态"},{value:"draft",label:"草稿"},{value:"pending",label:"待审批"},{value:"approving",label:"审批中"},{value:"approved",label:"已通过"},{value:"rejected",label:"已驳回"},{value:"cancelled",label:"已撤销"}],E={travel:"差旅费用",office:"办公费用",entertainment:"招待费用",training:"培训费用",other:"其他费用"},L={draft:{background:"#f5f5f5",color:"#666"},pending:{background:"#fff7e6",color:"#fa8c16"},approving:{background:"#e6f7ff",color:"#1890ff"},approved:{background:"#f6ffed",color:"#52c41a"},rejected:{background:"#fff1f0",color:"#f5222d"},cancelled:{background:"#f5f5f5",color:"#999"}},$={draft:"草稿",pending:"待审批",approving:"审批中",approved:"已通过",rejected:"已驳回",cancelled:"已撤销"},O=({user:n,onViewDetail:r,onEdit:I})=>{const[x,m]=o.useState([]),[f,b]=o.useState(!1),[d,u]=o.useState("all"),[i,p]=o.useState({page:1,limit:10,total:0}),l=async()=>{b(!0);try{const a={user_id:n==null?void 0:n.id,status:d,page:i.page,limit:i.limit},t=await c.get("/reimbursement/list",{params:a});t.data.success&&(m(t.data.data),p(k=>{var g;return{...k,total:((g=t.data.pagination)==null?void 0:g.total)||0}}))}catch(a){console.error("获取报销记录失败:",a),s.error("获取数据失败")}finally{b(!1)}};o.useEffect(()=>{n!=null&&n.id&&l()},[n==null?void 0:n.id,d,i.page]);const j=async a=>{try{const t=await c.post(`/reimbursement/${a}/submit`);t.data.success?(s.success("提交成功"),l()):s.error(t.data.message||"提交失败")}catch(t){console.error("提交失败:",t),s.error("提交失败")}},v=async a=>{h.confirm({title:"确认撤销",content:"确定要撤销此报销申请吗？撤销后可重新编辑提交。",okText:"确认撤销",cancelText:"取消",onOk:async()=>{try{const t=await c.post(`/reimbursement/${a}/cancel`);t.data.success?(s.success("已撤销"),l()):s.error(t.data.message||"操作失败")}catch(t){console.error("撤销失败:",t),s.error("操作失败")}}})},y=async a=>{h.confirm({title:"确认删除",content:"确定要删除此报销草稿吗？删除后无法恢复。",okText:"确认删除",okType:"danger",cancelText:"取消",onOk:async()=>{try{const t=await c.delete(`/reimbursement/${a}`);t.data.success?(s.success("已删除"),l()):s.error(t.data.message||"删除失败")}catch(t){console.error("删除失败:",t),s.error("删除失败")}}})};return e.jsxs("div",{className:"reimbursement-list",children:[e.jsx("style",{children:`
        .reimbursement-list {
          padding: 24px;
        }
        .list-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 20px;
        }
        .list-title {
          font-size: 18px;
          font-weight: 600;
          color: #1a1a2e;
        }
        .list-actions {
          display: flex;
          gap: 12px;
          align-items: center;
        }
        .filter-select {
          padding: 8px 12px;
          border: 1px solid #ddd;
          border-radius: 8px;
          font-size: 14px;
          background: white;
        }
        .btn-refresh {
          padding: 8px 12px;
          border: 1px solid #ddd;
          border-radius: 8px;
          background: white;
          cursor: pointer;
          display: flex;
          align-items: center;
          gap: 6px;
        }
        .btn-refresh:hover {
          background: #f5f5f5;
        }
        .list-table {
          background: white;
          border-radius: 12px;
          overflow: hidden;
          box-shadow: 0 2px 8px rgba(0,0,0,0.06);
        }
        .table {
          width: 100%;
          border-collapse: collapse;
        }
        .table th, .table td {
          padding: 14px 16px;
          text-align: center;
          vertical-align: middle;
          border-bottom: 1px solid #eee;
        }
        .table th {
          background: #f8f9fa;
          font-weight: 600;
          font-size: 13px;
          color: #555;
          text-align: center;
        }
        .table tr:hover td {
          background: #fafafa;
        }
        .reimbursement-no {
          font-family: monospace;
          color: #667eea;
          font-weight: 500;
        }
        .type-badge {
          padding: 4px 8px;
          border-radius: 4px;
          font-size: 12px;
          background: #f0f0f0;
          color: #666;
        }
        .status-badge {
          display: inline-block;
          padding: 4px 10px;
          border-radius: 12px;
          font-size: 12px;
          font-weight: 500;
        }
        .amount {
          font-weight: 600;
          color: #1a1a2e;
        }
        .date {
          color: #888;
          font-size: 13px;
        }
        .action-btns {
          display: flex;
          gap: 8px;
          justify-content: center;
        }
        .action-btn {
          padding: 6px 10px;
          border: none;
          border-radius: 6px;
          font-size: 12px;
          cursor: pointer;
          display: flex;
          align-items: center;
          gap: 4px;
          transition: all 0.2s;
        }
        .action-btn.view {
          background: #e6f7ff;
          color: #1890ff;
        }
        .action-btn.submit {
          background: #f0f5ff;
          color: #667eea;
        }
        .action-btn.cancel {
          background: #fff7e6;
          color: #fa8c16;
        }
        .action-btn.delete {
          background: #fff1f0;
          color: #f5222d;
        }
        .action-btn:hover {
          opacity: 0.8;
          transform: translateY(-1px);
        }
        .empty-state {
          text-align: center;
          padding: 60px 20px;
          color: #999;
        }
        .empty-icon {
          font-size: 48px;
          margin-bottom: 12px;
        }
        .pagination {
          display: flex;
          justify-content: flex-end;
          align-items: center;
          gap: 8px;
          padding: 16px;
          background: #f8f9fa;
        }
        .page-btn {
          padding: 6px 12px;
          border: 1px solid #ddd;
          border-radius: 6px;
          background: white;
          cursor: pointer;
        }
        .page-btn:disabled {
          opacity: 0.5;
          cursor: not-allowed;
        }
        .page-info {
          color: #666;
          font-size: 13px;
        }
        .loading-overlay {
          text-align: center;
          padding: 40px;
          color: #999;
        }
      `}),e.jsxs("div",{className:"list-header",children:[e.jsx("h2",{className:"list-title",children:"我的报销"}),e.jsxs("div",{className:"list-actions",children:[e.jsx("select",{className:"filter-select",value:d,onChange:a=>u(a.target.value),children:R.map(a=>e.jsx("option",{value:a.value,children:a.label},a.value))}),e.jsxs("button",{className:"btn-refresh",onClick:l,disabled:f,children:[e.jsx(N,{})," 刷新"]})]})]}),e.jsx("div",{className:"list-table",children:f?e.jsx("div",{className:"loading-overlay",children:"加载中..."}):x.length===0?e.jsxs("div",{className:"empty-state",children:[e.jsx("div",{className:"empty-icon",children:e.jsx(S,{})}),e.jsx("div",{children:"暂无报销记录"})]}):e.jsxs(e.Fragment,{children:[e.jsxs("table",{className:"table",children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"标题"}),e.jsx("th",{children:"类型"}),e.jsx("th",{children:"金额"}),e.jsx("th",{children:"状态"}),e.jsx("th",{children:"创建时间"}),e.jsx("th",{children:"操作"})]})}),e.jsx("tbody",{children:x.map(a=>e.jsxs("tr",{children:[e.jsx("td",{children:a.title}),e.jsx("td",{children:e.jsx("span",{className:"type-badge",children:E[a.type]||a.type})}),e.jsx("td",{children:e.jsxs("span",{className:"amount",children:["¥ ",parseFloat(a.total_amount).toFixed(2)]})}),e.jsx("td",{children:e.jsx("span",{className:"status-badge",style:L[a.status],children:$[a.status]||a.status})}),e.jsx("td",{children:e.jsx("span",{className:"date",children:new Date(a.created_at).toLocaleDateString()})}),e.jsx("td",{children:e.jsxs("div",{className:"action-btns",children:[e.jsxs("button",{className:"action-btn view",onClick:()=>r==null?void 0:r(a),children:[e.jsx(w,{})," 查看"]}),a.status==="draft"&&e.jsxs(e.Fragment,{children:[e.jsxs("button",{className:"action-btn submit",onClick:()=>j(a.id),children:[e.jsx(T,{})," 提交"]}),e.jsx("button",{className:"action-btn delete",onClick:()=>y(a.id),children:e.jsx(z,{})})]}),["pending","approving"].includes(a.status)&&e.jsxs("button",{className:"action-btn cancel",onClick:()=>v(a.id),children:[e.jsx(C,{})," 撤销"]})]})})]},a.id))})]}),e.jsxs("div",{className:"pagination",children:[e.jsxs("span",{className:"page-info",children:["共 ",i.total," 条"]}),e.jsx("button",{className:"page-btn",disabled:i.page<=1,onClick:()=>p(a=>({...a,page:a.page-1})),children:"上一页"}),e.jsx("button",{className:"page-btn",disabled:i.page*i.limit>=i.total,onClick:()=>p(a=>({...a,page:a.page+1})),children:"下一页"})]})]})})]})};export{O as default};
