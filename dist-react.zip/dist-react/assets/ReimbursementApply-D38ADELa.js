import{r as d,j as e,ce as I,aS as J,bW as L,d1 as W,d2 as X,av as Y,bX as H,ak as K,t as n}from"./vendor-DWOfZFgs.js";import{a as c}from"./api-C-56DNPF.js";import{a as O}from"./fileUtils-DzGHaMdL.js";import"./index-DcbpR3nA.js";const te=({user:s,onSuccess:b})=>{const[x,$]=d.useState([]),[R,F]=d.useState([]),[i,p]=d.useState({title:"",type:"",remark:""}),[l,u]=d.useState([{item_type:"",amount:"",expense_date:"",description:""}]),[m,y]=d.useState([]),[j,v]=d.useState(!1),[w,N]=d.useState(!1),[_,k]=d.useState(!1),[f,z]=d.useState(null);d.useEffect(()=>{D()},[]);const D=async()=>{try{const[t,r]=await Promise.all([c.get("/reimbursement/types"),c.get("/reimbursement/expense-types")]);if(t.data.success){const a=t.data.data.filter(o=>o.is_active);$(a),a.length>0&&!i.type&&p(o=>({...o,type:a[0].code||a[0].name}))}r.data.success&&F(r.data.data.filter(a=>a.is_active))}catch(t){console.error("获取配置失败:",t)}},S=l.reduce((t,r)=>{const a=parseFloat(r.amount)||0;return t+a},0),T=()=>{u([...l,{item_type:"",amount:"",expense_date:"",description:""}])},A=t=>{if(l.length===1){n.warning("至少需要一条费用明细");return}u(l.filter((r,a)=>a!==t))},g=(t,r,a)=>{const o=[...l];o[t][r]=a,u(o)},E=async t=>{const r=t.target.files;if(!(!r||r.length===0)){v(!0);for(const a of r){if(!["image/jpeg","image/png","image/jpg","application/pdf"].includes(a.type)){n.error(`文件 ${a.name} 格式不支持，只支持 JPG、PNG、PDF`);continue}if(a.size>10*1024*1024){n.error(`文件 ${a.name} 超过10MB限制`);continue}try{const h=new FormData;h.append("file",a);const C=await c.post("/upload",h,{headers:{"Content-Type":"multipart/form-data"}});C.data.success&&y(B=>[...B,{id:Date.now(),file_name:a.name,file_type:a.type,file_size:a.size,file_url:C.data.url,isNew:!0}])}catch(h){console.error("上传失败:",h),n.error(`文件 ${a.name} 上传失败`)}}v(!1),t.target.value=""}},P=t=>{y(m.filter((r,a)=>a!==t))},G=t=>{const r=O(t.file_url);r?window.open(r,"_blank"):n.error("无法生成预览地址")},M=()=>{if(!i.title.trim())return n.error("请填写报销标题"),!1;if(!i.type)return n.error("请选择报销类型"),!1;if(l.length===0)return n.error("请至少添加一条费用明细"),!1;if(m.length===0)return n.error("请上传发票或相关附件图片"),!1;for(let t=0;t<l.length;t++){const r=l[t];if(!r.item_type)return n.error(`第 ${t+1} 条明细：请选择费用类型`),!1;if(!r.amount||parseFloat(r.amount)<=0)return n.error(`第 ${t+1} 条明细：请填写有效金额`),!1}return!0},q=async()=>{if(!i.title.trim()){n.error("请至少填写报销标题");return}k(!0);try{const t={...i,user_id:s==null?void 0:s.id,employee_id:s==null?void 0:s.employee_id,department_id:s==null?void 0:s.department_id,items:l.filter(a=>a.item_type&&a.amount),attachments:m};let r;f?r=await c.put(`/reimbursement/${f}`,t):(r=await c.post("/reimbursement/apply",t),r.data.success&&z(r.data.data.id)),r.data.success?n.success("草稿保存成功"):n.error(r.data.message||"保存失败")}catch(t){console.error("保存草稿失败:",t),n.error("保存失败")}finally{k(!1)}},U=async()=>{if(M()){N(!0);try{const t={...i,user_id:s==null?void 0:s.id,employee_id:s==null?void 0:s.employee_id,department_id:s==null?void 0:s.department_id,items:l,attachments:m};let r=f;if(f)await c.put(`/reimbursement/${f}`,t);else{const o=await c.post("/reimbursement/apply",t);if(o.data.success)r=o.data.data.id;else throw new Error(o.data.message)}const a=await c.post(`/reimbursement/${r}/submit`);a.data.success?(n.success("报销申请提交成功"),p({title:"",type:"",remark:""}),u([{item_type:"",amount:"",expense_date:"",description:""}]),y([]),z(null),x.length>0&&p(o=>({...o,type:x[0].code||x[0].name})),b==null||b()):n.error(a.data.message||"提交失败")}catch(t){console.error("提交申请失败:",t),n.error(t.message||"提交失败")}finally{N(!1)}}};return e.jsxs("div",{className:"reimbursement-apply",children:[e.jsx("style",{children:`
        .reimbursement-apply {
          padding: 32px;
          max-width: 1000px;
          margin: 0 auto;
        }
        .section {
          background: white;
          border-radius: 16px;
          padding: 32px;
          margin-bottom: 24px;
          box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
          border: 1px solid #f3f4f6;
        }
        .section-title {
          font-size: 18px;
          font-weight: 700;
          color: #111827;
          margin-bottom: 24px;
          display: flex;
          align-items: center;
          gap: 8px;
        }
        .section-title::before {
          content: '';
          display: inline-block;
          width: 4px;
          height: 18px;
          background: #667eea;
          border-radius: 2px;
        }
        .form-grid {
          display: grid;
          grid-template-columns: 2fr 1fr;
          gap: 24px;
          margin-bottom: 24px;
        }
        .form-group {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }
        .form-label {
          font-size: 14px;
          font-weight: 600;
          color: #374151;
        }
        .form-label.required::after {
          content: '*';
          color: #ef4444;
          margin-left: 4px;
        }
        .form-input, .form-select, .form-textarea {
          padding: 12px 16px;
          border: 1px solid #d1d5db;
          border-radius: 10px;
          font-size: 15px;
          color: #111827;
          transition: all 0.2s;
          background: #fff;
        }
        .form-input:focus, .form-select:focus, .form-textarea:focus {
          outline: none;
          border-color: #667eea;
          box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        .form-textarea {
          min-height: 100px;
          resize: vertical;
          line-height: 1.5;
        }
        .items-header {
          display: grid;
          grid-template-columns: 180px 140px 160px 1fr 50px;
          gap: 16px;
          padding: 0 16px 12px 16px;
          font-size: 13px;
          font-weight: 600;
          color: #6b7280;
          text-transform: uppercase;
          letter-spacing: 0.05em;
        }
        .item-row {
          display: grid;
          grid-template-columns: 180px 140px 160px 1fr 50px;
          gap: 16px;
          align-items: flex-start;
          padding: 20px;
          background: #fff;
          border: 1px solid #e5e7eb;
          border-radius: 12px;
          margin-bottom: 16px;
          transition: all 0.2s;
        }
        .item-row:hover {
          border-color: #cbd5e1;
          box-shadow: 0 2px 4px rgba(0,0,0,0.02);
        }
        .btn-remove-item {
          width: 36px;
          height: 36px;
          border: 1px solid #fecaca;
          background: #fef2f2;
          color: #ef4444;
          border-radius: 10px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.2s;
          margin-top: 4px;
        }
        .btn-remove-item:hover {
          background: #fee2e2;
          color: #dc2626;
        }
        .btn-add-item {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          width: 100%;
          padding: 16px;
          border: 2px dashed #e5e7eb;
          background: transparent;
          color: #667eea;
          border-radius: 12px;
          cursor: pointer;
          font-size: 15px;
          font-weight: 600;
          transition: all 0.2s;
          margin-bottom: 24px;
        }
        .btn-add-item:hover {
          border-color: #667eea;
          background: #f5f7ff;
        }
        .total-row {
          display: flex;
          justify-content: flex-end;
          align-items: baseline;
          gap: 12px;
          padding: 20px 0;
          margin-top: 12px;
          border-top: 2px solid #f3f4f6;
        }
        .total-label {
          font-size: 14px;
          font-weight: 500;
          color: #6b7280;
        }
        .total-amount {
          font-size: 22px;
          font-weight: 700;
          color: #111827;
          font-family: 'SF Mono', 'Monaco', 'Consolas', monospace;
        }
        .upload-area {
          border: 2px dashed #d1d5db;
          border-radius: 16px;
          padding: 40px 24px;
          text-align: center;
          cursor: pointer;
          transition: all 0.2s;
          display: block;
          background: #fdfdfd;
        }
        .upload-area:hover {
          border-color: #667eea;
          background: #f5f7ff;
        }
        .upload-icon {
          font-size: 40px;
          color: #9ca3af;
          margin-bottom: 12px;
        }
        .upload-text {
          color: #374151;
          font-size: 16px;
          font-weight: 600;
        }
        .upload-hint {
          color: #6b7280;
          font-size: 13px;
          margin-top: 8px;
        }
        .attachment-list {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
          gap: 16px;
          margin-top: 24px;
        }
        .attachment-item {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 12px 16px;
          background: white;
          border: 1px solid #e5e7eb;
          border-radius: 10px;
          font-size: 14px;
        }
        .attachment-icon {
          font-size: 20px;
          color: #667eea;
        }
        .attachment-name {
          flex: 1;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
          color: #374151;
          font-weight: 500;
        }
        .attachment-actions {
          display: flex;
          gap: 4px;
        }
        .attachment-btn {
          width: 30px;
          height: 30px;
          border: none;
          background: transparent;
          color: #6b7280;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 6px;
          transition: all 0.2s;
        }
        .attachment-btn:hover {
          background: #f3f4f6;
          color: #111827;
        }
        .attachment-btn.delete:hover {
          background: #fef2f2;
          color: #ef4444;
        }
        .action-bar {
          display: flex;
          justify-content: flex-end;
          gap: 16px;
          padding: 24px 0;
          margin-top: 8px;
        }
        .btn {
          display: inline-flex;
          align-items: center;
          gap: 10px;
          padding: 14px 32px;
          border: none;
          border-radius: 12px;
          font-size: 15px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s;
        }
        .btn:disabled {
          opacity: 0.5;
          cursor: not-allowed;
        }
        .btn-secondary {
          background: #fff;
          color: #374151;
          border: 1px solid #d1d5db;
        }
        .btn-secondary:hover:not(:disabled) {
          background: #f9fafb;
          border-color: #9ca3af;
        }
        .btn-primary {
          background: #667eea;
          color: white;
        }
        .btn-primary:hover:not(:disabled) {
          background: #5a6fd1;
          box-shadow: 0 4px 12px rgba(102,126,234,0.3);
          transform: translateY(-1px);
        }
      `}),e.jsxs("div",{className:"section",children:[e.jsx("h3",{className:"section-title",children:"基本信息"}),e.jsxs("div",{className:"form-grid",children:[e.jsxs("div",{className:"form-group",children:[e.jsx("label",{className:"form-label required",children:"报销标题"}),e.jsx("input",{type:"text",className:"form-input",placeholder:"如：12月份差旅费报销",value:i.title,onChange:t=>p({...i,title:t.target.value})})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{className:"form-label required",children:"报销类型"}),e.jsxs("select",{className:"form-select",value:i.type,onChange:t=>p({...i,type:t.target.value}),children:[e.jsx("option",{value:"",disabled:!0,children:"请选择"}),x.map(t=>e.jsx("option",{value:t.code||t.name,children:t.name},t.id))]})]})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{className:"form-label",children:"备注说明"}),e.jsx("textarea",{className:"form-textarea",placeholder:"请在此输入补充说明...",value:i.remark,onChange:t=>p({...i,remark:t.target.value})})]})]}),e.jsxs("div",{className:"section",children:[e.jsx("h3",{className:"section-title",children:"费用明细"}),e.jsxs("div",{className:"items-header",children:[e.jsx("div",{children:"费用类型"}),e.jsx("div",{children:"金额 (元)"}),e.jsx("div",{children:"发生日期"}),e.jsx("div",{children:"费用说明"}),e.jsx("div",{})]}),l.map((t,r)=>e.jsxs("div",{className:"item-row",children:[e.jsxs("select",{className:"form-select",value:t.item_type,onChange:a=>g(r,"item_type",a.target.value),children:[e.jsx("option",{value:"",children:"选择类型"}),R.map(a=>e.jsx("option",{value:a.name,children:a.name},a.id))]}),e.jsx("input",{type:"number",className:"form-input",placeholder:"0.00",min:"0",step:"0.01",value:t.amount,onChange:a=>g(r,"amount",a.target.value)}),e.jsx("input",{type:"date",className:"form-input",value:t.expense_date,onChange:a=>g(r,"expense_date",a.target.value)}),e.jsx("input",{type:"text",className:"form-input",placeholder:"请输入用途说明",value:t.description,onChange:a=>g(r,"description",a.target.value)}),e.jsx("button",{className:"btn-remove-item",onClick:()=>A(r),title:"移除此项",children:e.jsx(I,{})})]},r)),e.jsxs("button",{className:"btn-add-item",onClick:T,children:[e.jsx(J,{})," 添加一条费用明细"]}),e.jsxs("div",{className:"total-row",children:[e.jsx("span",{className:"total-label",children:"报销总金额合计"}),e.jsxs("span",{className:"total-amount",children:["¥ ",S.toLocaleString("zh-CN",{minimumFractionDigits:2,maximumFractionDigits:2})]})]})]}),e.jsxs("div",{className:"section",children:[e.jsx("h3",{className:"section-title",children:"发票/附件"}),e.jsxs("label",{className:"upload-area",children:[e.jsx("input",{type:"file",multiple:!0,accept:".jpg,.jpeg,.png,.pdf",style:{display:"none"},onChange:E,disabled:j}),e.jsx("div",{className:"upload-icon",children:e.jsx(L,{})}),e.jsx("div",{className:"upload-text",children:j?"上传中...":"点击或拖拽文件到此处上传"}),e.jsx("div",{className:"upload-hint",children:"支持 JPG、PNG、PDF 格式，单个文件不超过 10MB"})]}),m.length>0&&e.jsx("div",{className:"attachment-list",children:m.map((t,r)=>{var a;return e.jsxs("div",{className:"attachment-item",children:[e.jsx("span",{className:"attachment-icon",children:(a=t.file_type)!=null&&a.includes("pdf")?e.jsx(W,{}):e.jsx(X,{})}),e.jsx("span",{className:"attachment-name",title:t.file_name,children:t.file_name}),e.jsxs("div",{className:"attachment-actions",children:[e.jsx("button",{className:"attachment-btn",onClick:()=>G(t),children:e.jsx(Y,{})}),e.jsx("button",{className:"attachment-btn delete",onClick:()=>P(r),children:e.jsx(I,{})})]})]},t.id||r)})})]}),e.jsxs("div",{className:"action-bar",children:[e.jsxs("button",{className:"btn btn-secondary",onClick:q,disabled:_,children:[e.jsx(H,{})," ",_?"保存中...":"保存草稿"]}),e.jsxs("button",{className:"btn btn-primary",onClick:U,disabled:w,children:[e.jsx(K,{})," ",w?"提交中...":"提交申请"]})]})]})};export{te as default};
