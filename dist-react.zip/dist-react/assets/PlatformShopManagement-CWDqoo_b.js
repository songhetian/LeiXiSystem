import{r as a,j as e,b1 as se,b2 as te,c as ae,t as l,b3 as ne,b4 as ie,b5 as oe,b6 as R,b7 as B,b8 as V}from"./vendor-DWOfZFgs.js";import{q as d}from"./qualityAPI-nxEzqXdH.js";import{M as E}from"./index-CnF8DO7N.js";import"./api-DDH_bzoq.js";const W=({entity:m,onSave:P,onCancel:p})=>{const[r,b]=a.useState(""),[u,c]=a.useState("");a.useEffect(()=>{b(m&&m.name||""),c("")},[m]);const y=o=>{if(o.preventDefault(),!r.trim()){c("名称不能为空");return}if(r.trim().length<2){c("名称至少需要2个字符");return}P({name:r.trim()})};return e.jsxs("form",{onSubmit:y,className:"flat-form",children:[e.jsx("div",{className:"form-content",children:e.jsxs("div",{className:"form-group",children:[e.jsxs("label",{htmlFor:"name",className:"form-label",children:[e.jsx(se,{className:"label-icon"}),e.jsx("span",{children:"名称"}),e.jsx("span",{className:"required-mark",children:"*"})]}),e.jsx("div",{className:"input-wrapper",children:e.jsx("input",{type:"text",id:"name",value:r,onChange:o=>{b(o.target.value),c("")},className:`form-input ${u?"input-error":""}`,placeholder:"请输入名称...",autoFocus:!0})})]})}),e.jsxs("div",{className:"form-footer",children:[e.jsxs("button",{type:"button",onClick:p,className:"btn-flat btn-cancel",children:[e.jsx(te,{className:"btn-icon"}),"取消"]}),e.jsxs("button",{type:"submit",className:"btn-flat btn-submit",disabled:!r.trim()||!!u,children:[e.jsx(ae,{className:"btn-icon"}),"保存"]})]}),e.jsx("style",{jsx:!0,children:`
                .flat-form {
                    display: flex;
                    flex-direction: column;
                    min-height: 200px;
                }

                .form-content {
                    flex: 1;
                    padding: 24px;
                }

                .form-group {
                    margin-bottom: 20px;
                }

                .form-label {
                    display: flex;
                    align-items: center;
                    gap: 8px;
                    font-size: 14px;
                    font-weight: 600;
                    color: #374151;
                    margin-bottom: 12px;
                }

                .label-icon {
                    width: 18px;
                    height: 18px;
                    color: #6b7280;
                }

                .required-mark {
                    color: #ef4444;
                    font-weight: 700;
                }

                .input-wrapper {
                    position: relative;
                }

                .form-input {
                    width: 100%;
                    padding: 12px 16px;
                    font-size: 15px;
                    color: #111827;
                    background: #f9fafb;
                    border: 2px solid #e5e7eb;
                    border-radius: 10px;
                    transition: all 0.2s ease;
                    outline: none;
                }

                .form-input:hover {
                    background: #ffffff;
                    border-color: #d1d5db;
                }

                .form-input:focus {
                    background: #ffffff;
                    border-color: #3b82f6;
                    box-shadow: 0 0 0 4px rgba(59, 130, 246, 0.1);
                }

                .form-input.input-error {
                    border-color: #ef4444;
                    background: #fef2f2;
                }

                .form-input.input-error:focus {
                    box-shadow: 0 0 0 4px rgba(239, 68, 68, 0.1);
                }

                .error-message {
                    display: flex;
                    align-items: center;
                    gap: 6px;
                    margin-top: 8px;
                    padding: 8px 12px;
                    background: #fef2f2;
                    border: 1px solid #fecaca;
                    border-radius: 6px;
                    color: #dc2626;
                    font-size: 13px;
                    font-weight: 500;
                }

                .error-icon {
                    width: 16px;
                    height: 16px;
                    flex-shrink: 0;
                }

                .success-hint {
                    display: flex;
                    align-items: center;
                    gap: 6px;
                    margin-top: 8px;
                    padding: 8px 12px;
                    background: #ecfdf5;
                    border: 1px solid #a7f3d0;
                    border-radius: 6px;
                    color: #059669;
                    font-size: 13px;
                    font-weight: 500;
                }

                .success-icon {
                    width: 16px;
                    height: 16px;
                    flex-shrink: 0;
                }

                .form-footer {
                    display: flex;
                    justify-content: flex-end;
                    gap: 12px;
                    padding: 16px 24px;
                    background: #f9fafb;
                    border-top: 1px solid #e5e7eb;
                }

                .btn-flat {
                    display: flex;
                    align-items: center;
                    gap: 6px;
                    padding: 10px 20px;
                    font-size: 14px;
                    font-weight: 600;
                    border: none;
                    border-radius: 8px;
                    cursor: pointer;
                    transition: all 0.2s ease;
                    outline: none;
                }

                .btn-icon {
                    width: 18px;
                    height: 18px;
                }

                .btn-cancel {
                    background: #ffffff;
                    color: #6b7280;
                    border: 2px solid #e5e7eb;
                }

                .btn-cancel:hover {
                    background: #f9fafb;
                    border-color: #d1d5db;
                    color: #374151;
                }

                .btn-cancel:active {
                    transform: scale(0.98);
                }

                .btn-submit {
                    background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
                    color: white;
                    border: 2px solid transparent;
                    box-shadow: 0 2px 4px rgba(59, 130, 246, 0.2);
                }

                .btn-submit:hover:not(:disabled) {
                    background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);
                    box-shadow: 0 4px 8px rgba(59, 130, 246, 0.3);
                    transform: translateY(-1px);
                }

                .btn-submit:active:not(:disabled) {
                    transform: translateY(0);
                }

                .btn-submit:disabled {
                    background: #e5e7eb;
                    color: #9ca3af;
                    cursor: not-allowed;
                    box-shadow: none;
                }

                @media (max-width: 640px) {
                    .form-content {
                        padding: 16px;
                    }

                    .form-footer {
                        padding: 12px 16px;
                        flex-direction: column-reverse;
                    }

                    .btn-flat {
                        width: 100%;
                        justify-content: center;
                    }
                }
            `})]})},me=()=>{const[m,P]=a.useState([]),[p,r]=a.useState([]),[b,u]=a.useState(!0),[c,y]=a.useState("card"),[o,_]=a.useState(""),[w,$]=a.useState(1),[M]=a.useState(6),[G,g]=a.useState(!1),[H,j]=a.useState(!1),[J,N]=a.useState(!1),[n,F]=a.useState(null),[x,O]=a.useState(null),[f,z]=a.useState(null),[h,D]=a.useState(null);a.useEffect(()=>{S()},[]),a.useEffect(()=>{if(o.trim()==="")r(m);else{const s=o.toLowerCase(),t=m.filter(i=>{var C;return i.name.toLowerCase().includes(s)||((C=i.shops)==null?void 0:C.some(ee=>ee.name.toLowerCase().includes(s)))});r(t)}$(1)},[o,m]);const S=async()=>{try{u(!0);const s=await d.getPlatforms(),t=await Promise.all((s.data.data||[]).map(async i=>{const C=await d.getShopsByPlatform(i.id);return{...i,shops:C.data.data||[]}}));P(t),r(t)}catch{l.error("加载平台和店铺数据失败")}finally{u(!1)}},K=()=>{O(null),g(!0)},I=s=>{O(s),g(!0)},q=s=>{F({type:"platform",id:s.id,name:s.name}),N(!0)},U=async()=>{if(n)try{n.type==="platform"?(await d.deletePlatform(n.id),l.success("平台删除成功！")):n.type==="shop"&&(await d.deleteShop(n.id),l.success("店铺删除成功！")),S()}catch{l.error(n.type==="platform"?"平台删除失败":"店铺删除失败")}finally{N(!1),F(null)}},X=async s=>{try{x?(await d.updatePlatform(x.id,s),l.success("平台更新成功！")):(await d.createPlatform(s),l.success("平台添加成功！")),g(!1),S()}catch{l.error(x?"平台更新失败":"平台添加失败")}},L=s=>{D(s),z(null),j(!0)},A=(s,t)=>{D(t),z(s),j(!0)},Q=s=>{F({type:"shop",id:s.id,name:s.name}),N(!0)},Z=async s=>{try{const t={...s,platform_id:h.id};f?(await d.updateShop(f.id,t),l.success("店铺更新成功！")):(await d.createShop(t),l.success("店铺添加成功！")),j(!1),S()}catch{l.error(f?"店铺更新失败":"店铺添加失败")}},k=Math.ceil(p.length/M),Y=(w-1)*M,T=Y+M,v=p.slice(Y,T);return b?e.jsxs("div",{className:"loading-container",children:[e.jsx("div",{className:"spinner"}),e.jsx("p",{children:"加载中..."})]}):e.jsxs("div",{className:"platform-shop-container",children:[e.jsxs("div",{className:"platform-shop-header",children:[e.jsxs("div",{children:[e.jsx("h2",{className:"platform-shop-title",children:"平台与店铺管理"}),e.jsxs("p",{className:"platform-shop-subtitle",children:["共 ",p.length," 个平台，",p.reduce((s,t)=>{var i;return s+(((i=t.shops)==null?void 0:i.length)||0)},0)," 个店铺"]})]}),e.jsxs("div",{className:"header-actions",children:[e.jsxs("div",{className:"search-box",children:[e.jsx(ne,{className:"search-icon"}),e.jsx("input",{type:"text",placeholder:"搜索平台或店铺...",value:o,onChange:s=>_(s.target.value),className:"search-input"})]}),e.jsxs("div",{className:"view-toggle",children:[e.jsx("button",{onClick:()=>y("card"),className:`toggle-btn ${c==="card"?"active":""}`,title:"卡片视图",children:e.jsx(ie,{className:"toggle-icon"})}),e.jsx("button",{onClick:()=>y("list"),className:`toggle-btn ${c==="list"?"active":""}`,title:"列表视图",children:e.jsx(oe,{className:"toggle-icon"})})]}),e.jsxs("button",{onClick:K,className:"btn-add-platform",children:[e.jsx(R,{className:"btn-icon"}),"添加平台"]})]})]}),v.length===0&&e.jsxs("div",{className:"empty-state-modern",children:[e.jsx("div",{className:"empty-icon",children:"🏪"}),e.jsx("p",{className:"empty-title",children:o?"未找到匹配的平台或店铺":"暂无平台数据"}),e.jsx("p",{className:"empty-subtitle",children:o?"请尝试其他搜索关键词":'点击"添加平台"按钮创建新平台'})]}),c==="card"&&v.length>0&&e.jsx("div",{className:"platforms-grid",children:v.map(s=>{var t;return e.jsxs("div",{className:"platform-card-modern",children:[e.jsxs("div",{className:"card-header",children:[e.jsx("h3",{className:"card-title",children:s.name}),e.jsxs("div",{className:"card-actions-header",children:[e.jsx("button",{onClick:()=>I(s),className:"icon-btn icon-btn-edit",title:"编辑平台",children:e.jsx(B,{className:"icon-btn-icon"})}),e.jsx("button",{onClick:()=>q(s.id),className:"icon-btn icon-btn-delete",title:"删除平台",children:e.jsx(V,{className:"icon-btn-icon"})})]})]}),e.jsxs("div",{className:"shop-count-badge",children:[e.jsx("span",{className:"badge-icon",children:"🏬"}),e.jsxs("span",{className:"badge-text",children:[((t=s.shops)==null?void 0:t.length)||0," 个店铺"]})]}),e.jsx("div",{className:"shops-section",children:s.shops&&s.shops.length>0?e.jsx("div",{className:"shops-list",children:s.shops.map(i=>e.jsxs("div",{className:"shop-item",children:[e.jsx("span",{className:"shop-name",children:i.name}),e.jsxs("div",{className:"shop-actions",children:[e.jsx("button",{onClick:()=>A(i,s),className:"shop-action-btn shop-edit",title:"编辑",children:e.jsx(B,{className:"shop-action-icon"})}),e.jsx("button",{onClick:()=>Q(i.id),className:"shop-action-btn shop-delete",title:"删除",children:e.jsx(V,{className:"shop-action-icon"})})]})]},i.id))}):e.jsxs("div",{className:"empty-shops",children:[e.jsx("span",{className:"empty-shops-icon",children:"📭"}),e.jsx("span",{className:"empty-shops-text",children:"暂无店铺"})]})}),e.jsx("div",{className:"card-footer",children:e.jsxs("button",{onClick:()=>L(s),className:"btn-add-shop",children:[e.jsx(R,{className:"btn-icon-small"}),"添加店铺"]})})]},s.id)})}),c==="list"&&v.length>0&&e.jsx("div",{className:"platforms-list",children:v.map(s=>e.jsxs("div",{className:"platform-list-item",children:[e.jsxs("div",{className:"list-item-header",children:[e.jsx("h3",{className:"list-item-title",children:s.name}),e.jsxs("div",{className:"list-item-actions",children:[e.jsxs("button",{onClick:()=>L(s),className:"btn-list-action btn-success",children:[e.jsx(R,{className:"btn-icon-small"}),"添加店铺"]}),e.jsx("button",{onClick:()=>I(s),className:"btn-list-action btn-secondary",children:"编辑平台"}),e.jsx("button",{onClick:()=>q(s.id),className:"btn-list-action btn-danger",children:"删除平台"})]})]}),e.jsxs("table",{className:"shops-table",children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"店铺名称"}),e.jsx("th",{className:"text-right",children:"操作"})]})}),e.jsx("tbody",{children:s.shops&&s.shops.length>0?s.shops.map(t=>e.jsxs("tr",{children:[e.jsx("td",{children:t.name}),e.jsxs("td",{className:"text-right",children:[e.jsx("button",{onClick:()=>A(t,s),className:"btn-table-action btn-edit",children:"编辑"}),e.jsx("button",{onClick:()=>Q(t.id),className:"btn-table-action btn-delete",children:"删除"})]})]},t.id)):e.jsx("tr",{children:e.jsx("td",{colSpan:"2",className:"empty-table-cell",children:"该平台下暂无店铺"})})})]})]},s.id))}),k>1&&e.jsxs("div",{className:"pagination-container",children:[e.jsx("button",{onClick:()=>$(s=>Math.max(1,s-1)),disabled:w===1,className:"pagination-btn",children:"上一页"}),e.jsxs("span",{className:"pagination-info",children:["第 ",w," 页 / 共 ",k," 页"]}),e.jsx("button",{onClick:()=>$(s=>Math.min(k,s+1)),disabled:w===k,className:"pagination-btn",children:"下一页"})]}),e.jsx(E,{isOpen:G,onClose:()=>g(!1),title:x?"编辑平台":"添加平台",variant:x?"warning":"success",children:e.jsx(W,{entity:x,onSave:X,onCancel:()=>g(!1)})}),e.jsx(E,{isOpen:H,onClose:()=>j(!1),title:f?`编辑店铺 (平台: ${h==null?void 0:h.name})`:`添加新店铺到 ${h==null?void 0:h.name}`,variant:f?"info":"primary",children:e.jsx(W,{entity:f,onSave:Z,onCancel:()=>j(!1)})}),e.jsxs(E,{isOpen:J,onClose:()=>N(!1),title:"确认删除",variant:"danger",size:"small",children:[e.jsxs("div",{className:"py-4",children:[e.jsx("p",{className:"text-gray-700 mb-4",children:(n==null?void 0:n.type)==="platform"?`确定要删除平台 "${n==null?void 0:n.name}" 吗？其下的所有店铺也将被删除。`:`确定要删除店铺 "${n==null?void 0:n.name}" 吗？`}),e.jsx("p",{className:"text-sm text-red-600 font-medium",children:"⚠️ 此操作不可撤销！"})]}),e.jsxs("div",{className:"flex justify-end gap-3 pt-4 border-t",children:[e.jsx("button",{onClick:()=>N(!1),className:"px-4 py-2 text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 font-medium",children:"取消"}),e.jsx("button",{onClick:U,className:"px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 font-medium",children:"确认删除"})]})]})]})};export{me as default};
